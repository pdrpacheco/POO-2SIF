package br.fiap.empregado;

public class Gerente extends Empregado implements Bonus {
	
	double salario;
	double bonus;
	
	public Gerente(String nome, String cpf, String matricula, double salario, double bonus) {
		super(nome, cpf, matricula);
		this.salario = salario;
		this.bonus = bonus;
	}

	@Override
	public double calcularBonus() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	

}
