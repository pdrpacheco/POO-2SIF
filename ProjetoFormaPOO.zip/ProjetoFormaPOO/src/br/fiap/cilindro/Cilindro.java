package br.fiap.cilindro;

import br.fiap.forma.Forma;
import br.fiap.volume.Volume;

public class Cilindro extends Forma implements Volume {

	private double altura;

	public Cilindro(int cx, int cy, double raio, double altura) {
		super(cx, cy, raio);
		this.altura = altura;
	}

	@Override
	public double calcularArea() {
		
		return 0;
	}
	
	public double calcularVolume() {
		
		return 0;
	}

}
