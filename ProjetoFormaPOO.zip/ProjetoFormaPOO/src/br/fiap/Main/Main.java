package br.fiap.Main;

import br.fiap.cilindro.Cilindro;
import br.fiap.circulo.Circulo;
import br.fiap.forma.Forma;
import br.fiap.volume.Volume;

public class Main {

	public static void main(String[] args) {

		Forma[] forma = new Forma[4];

		forma[0] = new Circulo(2, 3, 4);
		forma[1] = new Circulo(2, 3, 4);
		forma[2] = new Cilindro(2, 3, 4, 6);
		forma[3] = new Cilindro(2, 3, 4, 7);

		// imprimir a �rea de cada objeto
		for (Forma f : forma) {
			System.out.println(f.calcularArea() + "\n");
		}
		
		//imprimir volume
		for (Forma f : forma) {
			if (f instanceof Volume) {
				System.out.println(((Volume) f).calcularVolume());
			}
		}

	}

}
