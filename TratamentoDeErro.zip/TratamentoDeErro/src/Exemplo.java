import static javax.swing.JOptionPane.*;
import static java.lang.Double.*;


public class Exemplo {
	public static void main(String[] args) {
		
		double x, y, resultado;
		
		//parse converte para double
		try {
			x = parseDouble(showInputDialog("Digite o primeiro valor: "));
			y = parseDouble(showInputDialog("Digite o segundo valor: "));
			resultado = x / y;
			showMessageDialog(null, resultado);
		}
		catch(NumberFormatException e) {
			showMessageDialog(null, "Voc� deve digitar um n�mero");
		}
	}
}
