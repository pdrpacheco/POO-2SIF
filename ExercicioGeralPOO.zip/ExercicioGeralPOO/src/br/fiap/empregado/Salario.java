package br.fiap.empregado;

public interface Salario {
	
	public double calcularSalario();
}
