package br.fiap.pessoa;

public abstract class Pessoa {
	String nome;
	String cpf;
	
	
	public Pessoa(String nome, String cpf) {
		super();
		this.nome = nome;
		this.cpf = cpf;
	}
	
	@Override
	public String toString() {
		String aux;
		
		return aux; 
	}
	
	
}
