package br.fiapresort.main;

import br.fiapresort.hospede.Hospede;
import br.fiapresort.hotel.Resort;
import br.fiapresort.reserva.Reserva;

public class Main {

	public static void main(String[] args) {
		
		//array para armazenar os objetos Reserva
		Reserva[] reserva = new Reserva[4];
		
		Hospede h1 = new Hospede("123", "Jo�o", 0);
		Hospede h2 = new Hospede("456", "Jos�", 0);
		Hospede h3 = new Hospede("789", "Maria", 0);
		Hospede h4 = new Hospede("321", "Ana", 0);
		
		Resort r1 = new Resort("S�o Paulo", 5, "999");
		Resort r2 = new Resort("Rio de Janeiro", 3, "111");
		
		//Exe04
		reserva[0] = new Reserva(r1, h1);
		reserva[1] = new Reserva("07/05/2022", r2, h3);
		reserva[2] = new Reserva("23/02/2023",r1, h2);
		reserva[3] = new Reserva(r2, h4);
		
		//Exe05
		for(int i = 0; i <reserva.length; i++) {
			System.out.println(reserva[i].getDados());
		}
		
		//Exe06 
		for(int i = 0; i<reserva.length; i++) {
			if(reserva[i].getResort().getCidade() .equals("S�o Paulo") && reserva[i].getData().equals("25/04/2022")) {
				System.out.println(reserva[i].getDados());
			}
		}
		

	}

}
