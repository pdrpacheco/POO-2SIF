package br.fiap.empregado;

public interface Bonus {
	
	public double calcularBonus();
}
